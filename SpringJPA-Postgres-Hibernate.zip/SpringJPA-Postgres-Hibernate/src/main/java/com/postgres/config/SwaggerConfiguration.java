package com.postgres.config;



public class SwaggerConfiguration {


}
