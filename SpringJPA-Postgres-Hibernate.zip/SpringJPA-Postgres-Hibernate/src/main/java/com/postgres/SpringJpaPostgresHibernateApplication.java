package com.postgres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaPostgresHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaPostgresHibernateApplication.class, args);
	}

}
